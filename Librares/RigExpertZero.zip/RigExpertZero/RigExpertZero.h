/*
  RigExpertZero.h - Library for easy work with RigExpert AA-30.ZERO.
  Created by RigExpert Ltd., January 24, 2020.
  Released into the public domain.
*/

#ifndef RigExpertZero_h
#define RigExpertZero_h
 
#include "SoftwareSerial.h"
#include "Math.h"

#define MAX_FQ 30000000

class RigExpertZero
{
  public:
    RigExpertZero(int RX_Pin, int TX_Pin);
	bool startZero();
	bool startMeasure(int32_t fq);
	double getR();
	double getRp();
	double getX();
	double getXp();
	double getSWR();
	double getRL();
	double getZ();
	double getPhase();
	double getRho();
	
  private:
	bool computeSWR(double Z0, double R, double X);
	double computeZ (double R, double X);
	void computePhase (double R, double X);
	
	SoftwareSerial *m_ZERO;
	String m_inputBuffer;
	double m_Z0;
	double m_R;
	double m_X;
	double m_SWR;
	double m_RL;
	double m_Phase;
	double m_Rho;
	bool m_isZero;
};

#endif

