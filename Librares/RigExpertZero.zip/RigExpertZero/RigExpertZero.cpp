#include "RigExpertZero.h"

RigExpertZero::RigExpertZero(int RX_Pin, int TX_Pin)
{
	m_ZERO = new SoftwareSerial(RX_Pin, TX_Pin);
	m_Z0 = 50;
	m_R = 0;
	m_X = 0;
	m_SWR = 0;
	m_RL = 0;
	m_Phase = 0;
	m_Rho = 0;
	m_isZero = false;
}

bool RigExpertZero::startZero()
{
    m_ZERO->begin(38400);
	m_ZERO->flush();
    m_ZERO->write("\rVER\n");
	m_inputBuffer = "";
    for(int i = 0; i < 20000; ++i)
    {
        if (m_ZERO->available())
        {
            char c = m_ZERO->read();
            if(c != '\n' && c != '\r')
            {
                m_inputBuffer += c;
            }else
            {
                int i = m_inputBuffer.indexOf("ZERO");
                m_inputBuffer = "";
                if (i >= 0)
                {
                    m_isZero = true;
                    return true;
                }
            }
        }
    }
    return false;
}

bool RigExpertZero::startMeasure(int32_t fq)
{
	if(!m_isZero)
	{
		return false;
	}
	if(m_ZERO == NULL)
	{
		return false;
	}
	if(fq > MAX_FQ)
	{
		fq = MAX_FQ;
	}
    m_inputBuffer = "";
    bool isOk = false;
    int waitOkCounter = 0;
    m_ZERO->write("fq");
    m_ZERO->write(String(fq).c_str());
    m_ZERO->write("\n");
    
    while(!isOk)
    {
        if (m_ZERO->available())
        {
            char c = m_ZERO->read();
            if(c != '\n' && c != '\r')
            {
                m_inputBuffer += c;
            }else
            {                
                if(m_inputBuffer == "OK")
                {
                    isOk = true;
                }
                m_inputBuffer = "";
            }
        }
        if(++waitOkCounter >= 50000)
        {
            return false;
        }
    }
    
    m_ZERO->write("sw");
    m_ZERO->write(String(0).c_str());
    m_ZERO->write("\n");
    
    waitOkCounter = 0;
    isOk = false;
    while(!isOk)
    {
        if (m_ZERO->available())
        {
            char c = m_ZERO->read();
            if(c != '\n' && c != '\r')
            {
                m_inputBuffer += c;
            }else
            {
                if(m_inputBuffer == "OK")
                {
                    isOk = true;
                }
                m_inputBuffer = "";
            }
        }
        if(++waitOkCounter >= 50000)
        {
            return false;
        }
    }
    
    m_ZERO->write("frx");
    m_ZERO->write(String(0).c_str());
    m_ZERO->write("\n");
    
    waitOkCounter = 0;
    isOk = false;
    while(!isOk)
    {        
        if (m_ZERO->available())
        {
            char c = m_ZERO->read();
            if((c == '\n') || (c == '\r'))
            {                
                if(m_inputBuffer == "OK")
                {
                    m_inputBuffer = "";
                }else if(m_inputBuffer == "ERROR")
                {
                    m_inputBuffer = "";
                }else
                {
                    int i = m_inputBuffer.indexOf(',');
                    if (i > 0)
                    {
						waitOkCounter = 0;						
						isOk = true;
                        double Fq = m_inputBuffer.substring(0, i).toDouble();
                        i++;
                        m_R = m_inputBuffer.substring(i).toDouble();
                        int ii = m_inputBuffer.substring(i).indexOf(',');
                        m_X = m_inputBuffer.substring(i + ii + 1).toDouble();
						if ( isnan(m_R) || (m_R < 0.001 ))
						{
							m_R = 0.01;
						}
						if ( isnan(m_X))
						{
							m_X = 0;
						}						
                    }
                }
                m_inputBuffer = "";
            }else
			{
                m_inputBuffer += c;
            }            
        }
        if(++waitOkCounter >= 50000)
        {
            return false;
        }
    }
	
	waitOkCounter = 0;
    isOk = false;
    while(!isOk)
    {
        if (m_ZERO->available())
        {
            char c = m_ZERO->read();
            if(c != '\n' && c != '\r')
            {
                m_inputBuffer += c;
            }else
            {
                if(m_inputBuffer == "OK")
                {
                    isOk = true;
                }
                m_inputBuffer = "";
            }
        }
        if(++waitOkCounter >= 50000)
        {
            return false;
        }
    }
	
    return true;
}

bool RigExpertZero::computeSWR(double Z0, double R, double X)
{
    if (R <= 0)
    {
        R = 0.001;
    }
    double SWR, Gamma;
    double XX = X * X;
    double denominator = (R + Z0) * (R + Z0) + XX;

    if (denominator == 0)
    {
        return false;
    }
    Gamma = sqrt(((R - Z0) * (R - Z0) + XX) / denominator);
    if (Gamma == 1.0)
    {
        return false;
    }
    SWR = (1 + Gamma) / (1 - Gamma);

    if ((SWR > 200) || (Gamma > 0.99))
    {
        SWR = 200;
    } else if (SWR < 1)
    {
        SWR = 1;
    }
	m_SWR = SWR;
    

    m_RL = -20 * log10(Gamma);

    return true;
}

double RigExpertZero::computeZ (double R, double X)
{
    return sqrt((R*R) + (X*X));
}

void RigExpertZero::computePhase (double R, double X)
{
    double Rnorm = R/m_Z0;
    double Xnorm = X/m_Z0;
    double Denom = (Rnorm+1)*(Rnorm+1)+Xnorm*Xnorm;
    double RhoReal = ((Rnorm-1)*(Rnorm+1)+Xnorm*Xnorm)/Denom;
    double RhoImag = 2*Xnorm/Denom;
    m_Phase = atan2(RhoImag, RhoReal) / M_PI * 180.0;
    m_Rho = sqrt(RhoReal*RhoReal+RhoImag*RhoImag);
}

double RigExpertZero::getR()
{
    return m_R;
}

double RigExpertZero::getRp()
{
	return m_R*(1+m_X*m_X/m_R/m_R);
}

double RigExpertZero::getX()
{
    return m_X;
}

double RigExpertZero::getXp()
{
	return m_X*(1+m_R*m_R/m_X/m_X);
}

double RigExpertZero::getSWR()
{
	computeSWR(m_Z0, m_R, m_X);
    return m_SWR;
}

double RigExpertZero::getRL()
{
	computeSWR(m_Z0, m_R, m_X);
    return m_RL;
}

double RigExpertZero::getZ()
{
	return computeZ(m_R, m_X);
}

double RigExpertZero::getPhase()
{
	computePhase(m_R, m_X);
	return m_Phase;
}

double RigExpertZero::getRho()
{
	computePhase(m_R, m_X);
	return m_Rho;
}
